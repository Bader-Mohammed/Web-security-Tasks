<?php
session_start();

$x = "";
$answr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $thing = $_POST["thing"];

    if (isset($_POST["doit"])) {
        $x = password_hash($thing, PASSWORD_DEFAULT);
        $_SESSION["sav"] = $x;
    }

    if (isset($_POST["chek"])) {
        if (isset($_SESSION["sav"])) {
            if (password_verify($thing, $_SESSION["sav"])) {
                $answr = "mach";
            } else {
                $answr = "noo mach";
            }
            $x = $_SESSION["sav"];
        }
    }
}
?>

<html>
<body>

<form method="post">
    <input type="text" name="thing" placeholder="type somthing" required>
    <br><br>
    <input type="submit" name="doit" value="hash it">
    <input type="submit" name="chek" value="chek">
</form>

<br>

<?php
if ($x != "") {
    echo "the hash:<br>" . $x . "<br><br>";
}

if ($answr != "") {
    echo "answr: " . $answr;
}
?>

</body>
</html>
